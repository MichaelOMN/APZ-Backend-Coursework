package handler

import (
	"sport_app/pkg/service"

	"github.com/gin-gonic/gin"
)

type Handler struct {
	services *service.Service
}

func NewHandler(services *service.Service) *Handler {
	return &Handler{services: services}
}

func (h *Handler) InitRoutes() *gin.Engine {

	router := gin.New()

	auth := router.Group("/auth")
	{
		coachAuth := auth.Group("/coach")
		{
			coachAuth.POST("/sign-up", h.signUpCoach)
			coachAuth.POST("/sign-in", h.signInCoach)
		}
		visitorAuth := auth.Group("/visitor")
		{
			visitorAuth.POST("/sign-up", h.signUpVisitor)
			visitorAuth.POST("/sign-in", h.signInVisitor)
		}
	}

	api := router.Group("/api")
	{
		clubs := api.Group("/club", h.coachIdentity)
		{
			clubs.POST("/", h.createClub)
			clubs.GET("/", h.getAllClubs)
			clubs.GET("/:id", h.getClubById)
			//clubs.PUT("/:id", h.updateClub)
			clubs.DELETE("/:id", h.deleteClubById)
		}

		physicalInfos := api.Group("/phys_info", h.visitorIdentity)
		{
			physicalInfos.POST("/", h.createPhysicalInfo)
			//physicalInfos.GET("/", h.getAllPhysicalInfosByVisitorId)
			physicalInfos.GET("/:id", h.getPhysicalInfoByVisitorId)
			physicalInfos.PUT("/:id", h.updatePhysicalInfoByVisitorId)
			//physicalInfos.DELETE("/:id", h.deletePhysicalInfoByVisitorId)
		}

		trainings := api.Group("/training", h.coachIdentity)
		{
			trainings.POST("/", h.createTraining)
			//trainings.GET("/", h.getAllTrainings)
			trainings.GET("/:id", h.getTrainingById)
			//trainings.DELETE("/:id", h.deleteTrainingById)
		}

		statestypes := api.Group("/states_types", h.coachIdentity)
		{
			statestypes.POST("/", h.createST)
			//statestypes.GET("/", h.getAllST)
			statestypes.GET("/:id", h.getSTById)
			statestypes.PUT("/:id", h.updateSTById)
			//statestypes.DELETE("/:id", h.deleteSTById)
		}

		activity := api.Group("/activity", h.coachIdentity)
		{
			activity.POST("/", h.createActivity)
			//activity.GET("/", h.getAllActivities)
			activity.GET("/:id", h.getActivityById)
			//activity.PUT("/:id", h.updateActivityById)
			activity.DELETE("/:id", h.deleteActivityById)
		}

		attendance := api.Group("/attendance", h.visitorIdentity)
		{
			attendance.POST("/", h.createAttendance)
			//attendance.GET("/", h.getAllAttendanceByVisitorId)
			attendance.GET("/:id", h.getAttendanceByIdAndVisitorId)
			//attendance.PUT("/:id", h.updateAttendanceByVisitorId)
			//attendance.DELETE("/:id", h.deleteAttendanceByVisitorId)
		}

		actUsage := api.Group("/activity_usage", h.visitorIdentity)
		{
			actUsage.POST("/", h.createActUsage)
			//actUsage.GET("/", h.getAllActUsageByVisitorId)
			actUsage.GET("/:id", h.getActUsageByIdAndVisitorId)
			//actUsage.PUT("/:id", h.updateActUsageByVisitorId)
			//actUsage.DELETE("/:id", h.deleteActUsageByVisitorId)
		}

		pst := api.Group("/physical_state", h.visitorIdentity)
		{
			pst.POST("/", h.createPST)
			//pst.GET("/", h.getAllPSTByVisitorId)
			pst.GET("/:id", h.getPSTByVisitorId)
			//pst.DELETE("/:id", h.deletePSTByVisitorId)
		}

		ast := api.Group("/activity_state", h.visitorIdentity)
		{
			ast.POST("/", h.createAST)
			//ast.GET("/", h.getAllASTByVisitorId)
			ast.GET("/:id", h.getASTByVisitorId)
			//ast.DELETE("/:id", h.deleteASTByVisitorId)
		}

	}

	return router
}
