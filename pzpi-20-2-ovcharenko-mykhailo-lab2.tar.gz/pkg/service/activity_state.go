package service

import (
	entity "sport_app"
	"sport_app/pkg/repository"
)

type ActivityStateService struct {
	repo repository.ActivityState
}

func NewActivityStateService(repos repository.ActivityState) *ActivityStateService {
	return &ActivityStateService{repos}
}

func (ac *ActivityStateService) Create(a entity.ActivityState) (int, error) {
	return ac.repo.Create(a)
}

func (ac *ActivityStateService) GetAllByVisitorId(visitorId int) ([]entity.ActivityState, error) {
	return ac.repo.GetAllByVisitorId(visitorId)
}

func (ac *ActivityStateService) GetByVisitorId(visitorId, activityId int) (entity.ActivityState, error) {
	return ac.repo.GetByVisitorId(visitorId, activityId)
}

func (ac *ActivityStateService) Delete(visitorId, activityId int) error {
	return ac.repo.Delete(visitorId, activityId)
}
