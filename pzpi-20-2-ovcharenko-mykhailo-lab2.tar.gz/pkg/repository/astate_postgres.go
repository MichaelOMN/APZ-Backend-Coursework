package repository

import (
	entity "sport_app"

	"github.com/jmoiron/sqlx"
)

type ActivityStatePostgres struct {
	db *sqlx.DB
}

func NewActivityStatePostgres(db *sqlx.DB) *ActivityStatePostgres {
	return &ActivityStatePostgres{db}
}

func (asp *ActivityStatePostgres) Create(as entity.ActivityState) (int, error) {
	tx, err := asp.db.Begin()
	if err != nil {
		return -1, err
	}

	query := `insert into ActivityStates(state_type_id,unit_amount,at_datetime,activity_usage_id,duration_secs)
	values($1, $2, $3, $4, $5) returning id`

	row := tx.QueryRow(query, as.StateTypeId, as.UnitAmount, as.At, as.ActivityUsageId, as.Secs)
	var id int
	if err := row.Scan(&id); err != nil {
		return -1, err
	}

	return id, tx.Commit()
}

func (asp *ActivityStatePostgres) GetAllByVisitorId(visitorId int) ([]entity.ActivityState, error) {
	return []entity.ActivityState{}, nil
}

func (asp *ActivityStatePostgres) GetByVisitorId(visitorId, activityId int) (entity.ActivityState, error) {
	query := `select id,state_type_id,unit_amount,at_datetime,activity_usage_id,duration_secs
	from ActivityStates where id = $1 and activity_usage_id in (select id from ActivityUsage
	where visitor_id = $2)`

	var as entity.ActivityState
	err := asp.db.Get(&as, query, activityId, visitorId)
	if err != nil {
		return as, err
	}

	return as, nil
}

func (asp *ActivityStatePostgres) Delete(visitorId, activityId int) error {
	return nil
}
