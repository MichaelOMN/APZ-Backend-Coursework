package repository

import (
	entity "sport_app"

	"github.com/jmoiron/sqlx"
)

type ActivityUsagePostgres struct {
	db *sqlx.DB
}

func NewActivityUsagePostgres(db *sqlx.DB) *ActivityUsagePostgres {
	return &ActivityUsagePostgres{db}
}

func (a *ActivityUsagePostgres) Create(ac entity.ActivityUsage) (int, error) {
	tx, err := a.db.Begin()
	if err != nil {
		return -1, err
	}

	query := `insert into ActivityUsage(visitor_id, activity_id, usage_start_datetime, usage_end_datetime, training_id)
	values($1, $2, $3, $4, $5) returning id`

	row := tx.QueryRow(query, ac.VisitorId, ac.ActivityId, ac.Start, ac.End, ac.TrainingId)
	var id int
	if err := row.Scan(&id); err != nil {
		return -1, err
	}
	return id, tx.Commit()
}

func (a *ActivityUsagePostgres) GetAll(visitorId, activityId int) ([]entity.ActivityUsage, error) {
	return []entity.ActivityUsage{}, nil
}

func (a *ActivityUsagePostgres) GetById(visitorId, activityId int) (entity.ActivityUsage, error) {
	query := `select id, visitor_id, activity_id, usage_start_datetime, usage_end_datetime, training_id
	from ActivityUsage where visitor_id = $1 and activity_id = $2`
	var au entity.ActivityUsage
	err := a.db.Get(&au, query, visitorId, activityId)
	if err != nil {
		return au, err
	}
	return au, nil
}

func (a *ActivityUsagePostgres) Delete(visitorId, activityId int) error {
	return nil
}

func (a *ActivityUsagePostgres) Update(visitorId int, ac entity.ActivityUsageUpdateForm) error {
	if err := ac.Validate(); err != nil {
		return err
	}
	return nil
}
