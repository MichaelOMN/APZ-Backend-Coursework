curl -X POST http://localhost:8000/auth/visitor/sign-up -d \
'{"name":"michael1", "email":"mi@m.com", "phone":"+(380)993366580", "password":"qwerty123"}'

curl -X POST http://localhost:8000/auth/coach/sign-up -d \
'{"name":"michael2coach", "email":"mi@m.com", "phone":"+(380)993366580", "password":"qwerty123"}'

curl -X POST http://localhost:8000/auth/visitor/sign-in -d \
'{"login":"michael1", "password":"qwerty123"}'

curl -X POST http://localhost:8000/auth/coach/sign-in -d \
'{"login":"michael2coach", "password":"qwerty123"}'

curl -X POST http://localhost:8000/api/club/ -d \
'{"address": "м. Харків, вул. Героїв Праці, 20В", "name": "Геркулес"}' \
-H 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2ODY0MDU3MTMsImlhdCI6MTY4NjM2MjUxMywiZW50aXR5X2lkIjozfQ.esGRJXCZDcxPGygSOizXllSuEd3FFSes35uryYRTC90'

curl -X GET http://localhost:8000/api/club/ \
-H 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2ODY0MDU3MTMsImlhdCI6MTY4NjM2MjUxMywiZW50aXR5X2lkIjozfQ.esGRJXCZDcxPGygSOizXllSuEd3FFSes35uryYRTC90'

curl -X GET http://localhost:8000/api/club/1 \
-H 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2ODY0MDU3MTMsImlhdCI6MTY4NjM2MjUxMywiZW50aXR5X2lkIjozfQ.esGRJXCZDcxPGygSOizXllSuEd3FFSes35uryYRTC90'

curl -X POST http://localhost:8000/api/phys_info/ -d \
'{"height": 187.56, "weight":67.53}' \
-H 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2ODY0MDY0ODAsImlhdCI6MTY4NjM2MzI4MCwiZW50aXR5X2lkIjoxfQ.8vISKiWV3GBs07v7OI8OFju2dBtDtkn6ovuq2sj84Yk'

curl -X GET http://localhost:8000/api/phys_info/1 \
-H 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2ODY0MDY0ODAsImlhdCI6MTY4NjM2MzI4MCwiZW50aXR5X2lkIjoxfQ.8vISKiWV3GBs07v7OI8OFju2dBtDtkn6ovuq2sj84Yk'

curl -X PUT http://localhost:8000/api/phys_info/12 \
-d '{"height": "191.25", "weight": "75.0"}' \
-H 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2ODY0MDY0ODAsImlhdCI6MTY4NjM2MzI4MCwiZW50aXR5X2lkIjoxfQ.8vISKiWV3GBs07v7OI8OFju2dBtDtkn6ovuq2sj84Yk'

curl -X POST http://localhost:8000/api/training/ \
-d '{"start": "2023-06-09T00:26:35", "end": "2023-06-09T01:30:00", "coach_id": 1, "club_id": 1}' \
-H 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2ODYzMDcwNjgsImlhdCI6MTY4NjI2Mzg2OCwiZW50aXR5X2lkIjoyfQ.yRV2t4X3MEhy13jw_NDvTFcLxd3y9q2L1_YGPPIANb8'

curl -X GET http://localhost:8000/api/training/2 \
-H 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2ODYzMDcwNjgsImlhdCI6MTY4NjI2Mzg2OCwiZW50aXR5X2lkIjoyfQ.yRV2t4X3MEhy13jw_NDvTFcLxd3y9q2L1_YGPPIANb8'

curl -X POST http://localhost:8000/api/states_types/ \
-d '{"name": "beats per minute", "description": "measure of heart beats count per minute", "unit": "bpm"}' \
-H 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2ODYzMDcwNjgsImlhdCI6MTY4NjI2Mzg2OCwiZW50aXR5X2lkIjoyfQ.yRV2t4X3MEhy13jw_NDvTFcLxd3y9q2L1_YGPPIANb8'

curl -X GET http://localhost:8000/api/states_types/2 \
-H 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2ODYzMDcwNjgsImlhdCI6MTY4NjI2Mzg2OCwiZW50aXR5X2lkIjoyfQ.yRV2t4X3MEhy13jw_NDvTFcLxd3y9q2L1_YGPPIANb8'

curl -X PUT http://localhost:8000/api/states_types/2 \
-d '{"name": "сердечний ритм", "description": "кількість ударів серця за хвилину", "unit": "разів"}' \
-H 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2ODYzMDcwNjgsImlhdCI6MTY4NjI2Mzg2OCwiZW50aXR5X2lkIjoyfQ.yRV2t4X3MEhy13jw_NDvTFcLxd3y9q2L1_YGPPIANb8'

curl -X POST http://localhost:8000/api/activity/ \
-d '{"name": "велоергометр", "type_name": "тренажер", "type_description": "емітатор велосипеда з додатковим навантаженням", "description": "-", "club_id": 1}' \
-H 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2ODYzMDcwNjgsImlhdCI6MTY4NjI2Mzg2OCwiZW50aXR5X2lkIjoyfQ.yRV2t4X3MEhy13jw_NDvTFcLxd3y9q2L1_YGPPIANb8'

curl -X GET http://localhost:8000/api/activity/1 \
-H 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2ODYzMDcwNjgsImlhdCI6MTY4NjI2Mzg2OCwiZW50aXR5X2lkIjoyfQ.yRV2t4X3MEhy13jw_NDvTFcLxd3y9q2L1_YGPPIANb8'

curl -X DELETE http://localhost:8000/api/activity/1 \
-H 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2ODYzMDcwNjgsImlhdCI6MTY4NjI2Mzg2OCwiZW50aXR5X2lkIjoyfQ.yRV2t4X3MEhy13jw_NDvTFcLxd3y9q2L1_YGPPIANb8'

curl -X POST http://localhost:8000/api/attendance/ \
-d '{"training_id": 2}' \
-H 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2ODYzMTI3MzUsImlhdCI6MTY4NjI2OTUzNSwiZW50aXR5X2lkIjoxfQ.YMN7xkGnLdYrIvLRVe7tuiHJiIqxZDTXFP-mTeZZ2qk'

curl -X GET http://localhost:8000/api/attendance/3 \
-H 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2ODYzMTI3MzUsImlhdCI6MTY4NjI2OTUzNSwiZW50aXR5X2lkIjoxfQ.YMN7xkGnLdYrIvLRVe7tuiHJiIqxZDTXFP-mTeZZ2qk'

curl -X POST http://localhost:8000/api/activity_usage/ \
-d '{"activity_id": 2, "start": "2023-06-09T03:22:15", "end": "2023-06-09T03:24:15", "training_id": 2}' \
-H 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2ODYzMTI3MzUsImlhdCI6MTY4NjI2OTUzNSwiZW50aXR5X2lkIjoxfQ.YMN7xkGnLdYrIvLRVe7tuiHJiIqxZDTXFP-mTeZZ2qk'

curl -X GET http://localhost:8000/api/activity_usage/2 \
-H 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2ODYzMTI3MzUsImlhdCI6MTY4NjI2OTUzNSwiZW50aXR5X2lkIjoxfQ.YMN7xkGnLdYrIvLRVe7tuiHJiIqxZDTXFP-mTeZZ2qk'

curl -X POST http://localhost:8000/api/physical_state/ \
-d '{"activity_usage_id": 2, "unit_amount": 153, "state_type_id": 2, "at": "2023-06-09T03:23:16", "secs": 0}' \
-H 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2ODYzMTI3MzUsImlhdCI6MTY4NjI2OTUzNSwiZW50aXR5X2lkIjoxfQ.YMN7xkGnLdYrIvLRVe7tuiHJiIqxZDTXFP-mTeZZ2qk'

curl -X GET http://localhost:8000/api/physical_state/2 \
-H 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2ODYzMTI3MzUsImlhdCI6MTY4NjI2OTUzNSwiZW50aXR5X2lkIjoxfQ.YMN7xkGnLdYrIvLRVe7tuiHJiIqxZDTXFP-mTeZZ2qk'

curl -X POST http://localhost:8000/api/states_types/ \
-d '{"name": "power", "description": "the acceleration of a training equipment", "unit": "m/s^2"}' \
-H 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2ODYzMDcwNjgsImlhdCI6MTY4NjI2Mzg2OCwiZW50aXR5X2lkIjoyfQ.yRV2t4X3MEhy13jw_NDvTFcLxd3y9q2L1_YGPPIANb8'

curl -X POST http://localhost:8000/api/activity_state/ \
-d '{"activity_usage_id": 2, "unit_amount": 15, "state_type_id": 3, "at": "2023-06-09T03:23:16", "secs": 0}' \
-H 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2ODYzMTI3MzUsImlhdCI6MTY4NjI2OTUzNSwiZW50aXR5X2lkIjoxfQ.YMN7xkGnLdYrIvLRVe7tuiHJiIqxZDTXFP-mTeZZ2qk'

curl -X GET http://localhost:8000/api/activity_state/1 \
-H 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2ODYzMTI3MzUsImlhdCI6MTY4NjI2OTUzNSwiZW50aXR5X2lkIjoxfQ.YMN7xkGnLdYrIvLRVe7tuiHJiIqxZDTXFP-mTeZZ2qk'
